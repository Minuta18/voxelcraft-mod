require "voxelcraft:crafting/check_craft"
require "voxelcraft:crafting/stdcrafts"
require "voxelcraft:crafting/furnace"

craft = {}
craft.crafting = crafting
craft.furnaces = furnaces